#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import libsandmannplayer
import libsandmannjsonparser as libArdJsonParser
import libmediathek3 as libMediathek

params = libMediathek.get_params()

if sys.version_info[0] < 3:  # for Python 2
	from urllib import quote_plus
else:  # for Python 3
	from urllib.parse import quote_plus


def list():
	return libMediathek.list(modes, 'libArdListMain', 'libArdPlayClassic')


def libArdListMain():
	"""
	Modified version of the ARD Mediathek addon from the Gigathek repository.
	When started, all available videos for 'Sandmann' are loaded
	"""
	shows = libArdJsonParser.parseAZ()
	sandmann_directory_dict = next((x for x in shows if x["name"] == "Sandmann"), None)
	if sandmann_directory_dict:
		return libArdJsonParser.parseVideos(sandmann_directory_dict["url"])
	return shows


def libArdListVideos():
	return libArdJsonParser.parseVideos(params['url'])


def libArdPlayClassic():
	result = libsandmannplayer.getVideoUrlClassic(videoID=params['documentId'])
	result = libMediathek.getMetadata(result)
	return result


modes = {
	'libArdListMain': libArdListMain,
	'libArdListVideos': libArdListVideos,
	'libArdPlayClassic': libArdPlayClassic,
}