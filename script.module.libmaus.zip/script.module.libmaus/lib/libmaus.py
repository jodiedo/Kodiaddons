#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import libmausplayer
import libmausjsonparser as libArdJsonParser
import libmediathek3 as libMediathek

params = libMediathek.get_params()

if sys.version_info[0] < 3:  # for Python 2
	from urllib import quote_plus
else:  # for Python 3
	from urllib.parse import quote_plus


def list():
	return libMediathek.list(modes, 'libArdListMain', 'libArdPlayClassic')


def libArdListMain():
	"""
	Modified version of the ARD Mediathek addon from the Gigathek repository.
	When started, all available videos for 'Die Sendung mit der Maus' are loaded
	"""
	shows = libArdJsonParser.parseAZ()
	maus_directory_dict = next((x for x in shows if x["name"] == "Die Sendung mit der Maus"), None)
	if maus_directory_dict:
		return libArdJsonParser.parseVideos(maus_directory_dict["url"])
	return shows


def libArdListVideos():
	return libArdJsonParser.parseVideos(params['url'])


def libArdPlayClassic():
	result = libmausplayer.getVideoUrlClassic(videoID=params['documentId'])
	result = libMediathek.getMetadata(result)
	return result


modes = {
	'libArdListMain': libArdListMain,
	'libArdListVideos': libArdListVideos,
	'libArdPlayClassic': libArdPlayClassic,
}